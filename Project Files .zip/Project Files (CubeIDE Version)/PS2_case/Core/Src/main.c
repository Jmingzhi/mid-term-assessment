/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include"ps2.h"
#include <stdlib.h>//用abs函数
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 电机控制函数
void Motor_Stop() {
    HAL_GPIO_WritePin(motor1_A_GPIO_Port, motor1_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor1_B_GPIO_Port, motor1_B_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor2_A_GPIO_Port, motor2_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor2_B_GPIO_Port, motor2_B_Pin, GPIO_PIN_RESET);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
}

void Motor_Forward() {
    // 电机1（左轮）：A=1, B=0
    HAL_GPIO_WritePin(motor1_A_GPIO_Port, motor1_A_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor1_B_GPIO_Port, motor1_B_Pin, GPIO_PIN_RESET);
    // 电机2（右轮）：A=1, B=0
    HAL_GPIO_WritePin(motor2_A_GPIO_Port, motor2_A_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor2_B_GPIO_Port, motor2_B_Pin, GPIO_PIN_RESET);
}

void Motor_Backward() {
    // 电机1（左轮）：A=0, B=1
    HAL_GPIO_WritePin(motor1_A_GPIO_Port, motor1_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor1_B_GPIO_Port, motor1_B_Pin, GPIO_PIN_SET);
    // 电机2（右轮）：A=0, B=1
    HAL_GPIO_WritePin(motor2_A_GPIO_Port, motor2_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor2_B_GPIO_Port, motor2_B_Pin, GPIO_PIN_SET);
}

void Motor_SpinLeft() {
    // 原地左转：左轮后退，右轮前进
    // 左轮后退
    HAL_GPIO_WritePin(motor1_A_GPIO_Port, motor1_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor1_B_GPIO_Port, motor1_B_Pin, GPIO_PIN_SET);
    // 右轮前进
    HAL_GPIO_WritePin(motor2_A_GPIO_Port, motor2_A_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor2_B_GPIO_Port, motor2_B_Pin, GPIO_PIN_RESET);
}

void Motor_SpinRight() {
    // 原地右转：左轮前进，右轮后退
    // 左轮前进
    HAL_GPIO_WritePin(motor1_A_GPIO_Port, motor1_A_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor1_B_GPIO_Port, motor1_B_Pin, GPIO_PIN_RESET);
    // 右轮后退
    HAL_GPIO_WritePin(motor2_A_GPIO_Port, motor2_A_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor2_B_GPIO_Port, motor2_B_Pin, GPIO_PIN_SET);
}

int PS2_Control_Handler() {
//用返回值来进行部分的条件判断，增加可读性
//数字模式下无操作(兼遥控开关）
	if (PS2_Data.A_D == 0) {
		return 0;
	}
//激光控制
    static uint8_t last_state = 0;
    static uint32_t last_time = 0;
    //利用系统滴嗒来防抖
    if (PS2_Data.Key_R_Up == 1 && last_state == 0) //判断是不是按下操作
    {
        uint32_t current_time = HAL_GetTick();//获得当前时间
        //比较上次翻转的时间，防抖
        if (current_time - last_time > 300) {
            HAL_GPIO_TogglePin(light_GPIO_Port, light_Pin);
            last_time = current_time;
        }
    }
    last_state = PS2_Data.Key_R_Up;

//舵机控制
		//往上
	if (PS2_Data.Key_L_Up == 1) {
		//边界情况
		if (__HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_2) > 246) {
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 250);
		}
		else {
			int n = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_2);
			n += 4;//用4为单位来控制旋转
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, n);
		}
	}
	//往下
	else if (PS2_Data.Key_L_Down == 1) {

		if (__HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_2) < 54) {
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 50);
		}
		else {
			int n = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_2);
			n -= 4;
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, n);
		}
	}
	//往右
	else if (PS2_Data.Key_L_Left == 1) {
		if (__HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_1) > 246) {
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250);
		}
		else {
			int n = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_1);
			n += 4;
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, n);
		}
	}
	//往左
	else if (PS2_Data.Key_L_Right == 1) {
		if (__HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_1) < 54) {
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 50);
		}
		else {
			int n = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_1);
			n -= 4;
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, n);
		}
	}
//电机控制

    // 获取摇杆值
    int8_t forward_speed = PS2_Data.Rocker_LY;  // 左摇杆Y轴：前进/后退
    int8_t turn_speed = PS2_Data.Rocker_RX;     // 右摇杆X轴：转向

    // 将摇杆值(-128~127)转换为PWM占空比(0~2000)
        int16_t base_pwm = 0;
        int16_t left_pwm = 0, right_pwm = 0;

    // 定义死区
    #define MOTOR_DEADZONE 15
    #define TURN_DEADZONE 10

    // 应用死区
    if (forward_speed > -MOTOR_DEADZONE && forward_speed < MOTOR_DEADZONE) {
        forward_speed = 0;
    }
    if (turn_speed > -TURN_DEADZONE && turn_speed < TURN_DEADZONE) {
        turn_speed = 0;
    }



    if (forward_speed == 0 && turn_speed == 0) {
        // 停止
        Motor_Stop();
        return 0;
    }

    // 前/后控制
    if (forward_speed != 0) {
        // 计算速度大小（绝对值）
        base_pwm = abs(forward_speed) * 2000 / 127;
        if (base_pwm > 2000) base_pwm = 2000;//处理-128的情况

        // 转向控制
        if (turn_speed > 0) {  // 右转
            left_pwm = base_pwm;
            right_pwm = base_pwm * (127 - turn_speed) / 127;
        }
        else if (turn_speed < 0) {  // 左转
            if(turn_speed<-127){//处理-128的情况,int8_t 的范围是 -128 ~ +127，所以需在取绝对值前处理
            	turn_speed=-127;
            }
            turn_speed = 0-turn_speed;  // 取绝对值
            right_pwm = base_pwm;
            left_pwm = base_pwm * (127 - turn_speed) / 127;
        }
        else {  // 直行
            left_pwm = base_pwm;
            right_pwm = base_pwm;
        }

        // 设置方向
        if (forward_speed > 0) {
            // 前进
            Motor_Forward();
        } else {
            // 后退
            Motor_Backward();
        }

        // 设置PWM
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, left_pwm);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, right_pwm);

    }
    // 原地转向（前后速度为0，只有转向）
    else if (turn_speed != 0) {

        base_pwm = abs(turn_speed) * 2000 / 127;
        if (base_pwm > 2000) base_pwm = 2000;

        if (turn_speed > 0) {  // 原地右转
            Motor_SpinRight();  // 左轮前进，右轮后退
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, base_pwm);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, base_pwm);
        } else {  // 原地左转
            Motor_SpinLeft();   // 左轮后退，右轮前进
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, base_pwm);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, base_pwm);
        }
    }

    return 0;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  //初始化舵机的位置
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 150);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 150);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

      // 读取PS2数据
      PS2_Read_Data();

      // 处理PS2数据并控制外设
      PS2_Control_Handler();

      // 延时，控制循环频率
      HAL_Delay(20); // 50Hz
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 720-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 2000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 720-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 2000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, PS2_CLK_Pin|PS2_DO_Pin|motor2_A_Pin|motor2_B_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(PS2_CS_GPIO_Port, PS2_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, motor1_B_Pin|motor1_A_Pin|light_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PS2_CLK_Pin PS2_CS_Pin PS2_DO_Pin */
  GPIO_InitStruct.Pin = PS2_CLK_Pin|PS2_CS_Pin|PS2_DO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PS2_DI_Pin */
  GPIO_InitStruct.Pin = PS2_DI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(PS2_DI_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : motor1_B_Pin motor1_A_Pin light_Pin */
  GPIO_InitStruct.Pin = motor1_B_Pin|motor1_A_Pin|light_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : motor2_A_Pin motor2_B_Pin */
  GPIO_InitStruct.Pin = motor2_A_Pin|motor2_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
