#ifndef DELAY_DELAY_H_
#define DELAY_DELAY_H_

#include "stm32f1xx_hal.h" //HAL?????
void delay_us(uint32_t us); //C????????

#endif /* DELAY_DELAY_H_ */
