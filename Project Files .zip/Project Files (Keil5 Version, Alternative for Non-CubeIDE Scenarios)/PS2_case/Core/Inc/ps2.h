#ifndef PS2_PS2_H_
#define PS2_PS2_H_

#include "main.h"
#include "delay.h"
/*
??4?GPIO:
3??????? CLK DO CS
1??????? DI
*/

#define PS2_CS_GPIOx GPIOA
#define PS2_CS_Pin GPIO_PIN_2

#define PS2_CLK_GPIOx GPIOA
#define PS2_CLK_Pin GPIO_PIN_1

#define PS2_DO_GPIOx GPIOA
#define PS2_DO_Pin GPIO_PIN_3

#define PS2_DI_GPIOx GPIOA
#define PS2_DI_Pin GPIO_PIN_4

typedef struct
{
    uint8_t A_D;                                       //??(??)?1 ??(??)?0
    int8_t Rocker_RX, Rocker_RY, Rocker_LX, Rocker_LY; //???(????????0-0xFF)(????????0,0x80,0xFF)
    //???0????,1????
    uint8_t Key_L1, Key_L2, Key_R1, Key_R2;                //?????
    uint8_t Key_L_Right, Key_L_Left, Key_L_Up, Key_L_Down; //????
    uint8_t Key_R_Right, Key_R_Left, Key_R_Up, Key_R_Down; //????
    uint8_t Key_Select;                                    //???
    uint8_t Key_Start;                                     //???
    uint8_t Key_Rocker_Left, Key_Rocker_Right;             //????

} PS2_TypeDef;
extern PS2_TypeDef PS2_Data;
void PS2_Read_Data(void);

#endif /* PS2_PS2_H_ */
